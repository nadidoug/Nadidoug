Author : iDoodle

Project Name : Multipurpose, Business, Startup Banners HTML5 - Google Web Designer 


:::::::::::::::::::> BANNER CUSTOMIZATION INSTRUCTIONS <:::::::::::::::::::::::::::::::::::::

To begin, download and install Google Web Designer: https://www.google.com/webdesigner/

Once installed, start Google Web Designer and choose to open an existing file.

Navigate to the folder containing the HTML5 banner files that you purchased. Open folder "Main"

responsiveWebsite contains source files configured for Google Adwords / DoubleClick. 


:::::::::::::::::::> ADWORDS/DOUBLECLICK ADS TO NON-GOOGLE AD ENVIRONMENT CONVERSION <:::::::::::::::::::::::::::::::::::::

1,Create a new "Non-Google Ad" file. This will generate the "gwdgenericad_min.js" file. 

2,Copy the "gwdgenericad_min.js" from the New folder you just created  to the existing project folder of your GWD source html file that you want to convert. 

3,Open the file in GWD. 

4,Switch to Code View.

5,Find the following line and remove it:
	<script data-source="https://s0.2mdn.net/ads/studio/Enabler.js" data-exports-type="gwd-doubleclick" type="text/javascript" src="https://s0.2mdn.net/ads/studio/Enabler.js"></script>


6,Search for the following lines in the code:
 	<script data-source="gwddoubleclick_min.js" data-version="1.8" data-exports-type="gwd-doubleclick" type="text/javascript" src="gwddoubleclick_min.js"></script>

	Replace with the following line:

	<script data-source="gwdgenericad_min.js" data-version="1" data-exports-type="gwd-genericad" type="text/javascript" src="gwdgenericad_min.js"></script>

7,Find the following tag under <body> tag:

  	<gwd-doubleclick id="gwd-ad" polite-load="">
    		<gwd-metric-configuration></gwd-metric-configuration>

8,Replace with the following line:

   	<gwd-genericad id="gwd-ad">

 	Last, search for the following  close tag

	</gwd-doubleclick>

9,And replace  it with:

  	  </gwd-genericad>

 10,Save and reopen the file, Publish the file locally .


:::::::::::::::::::> HOW TO EDIT THE TEXT <:::::::::::::::::::::::::::::::::::::

Open your desired banner in Google Web Designer, click "Code view". Scroll down to the bottom(note: you can use 'ctrl+f') until you see the text you would like to replace, enter your own.

:::::::::::::::::::> HOW TO ADD YOUR LOGO <:::::::::::::::::::::::::::::::::::::

Google Web Designer isn't needed for this task. You can directly replace the image file (logo.png) found in the "assets" folder of the banner you are customizing. 

:::::::::::::::::::> HOW TO ADD YOUR IMAGE <:::::::::::::::::::::::::::::::::::::

Google Web Designer isn't needed for this task. You can directly replace the image file (mainpic.png) found in the "assets" folder of the banner you are customizing. 

:::::::::::::::::::> EDIT WEBSITE LINK <:::::::::::::::::::::::::::::::::::::

Expand the "Events" panel, double click the entry that begins with "gwd-taparea_1"

Add your website address into the URL text field and choose Save. 

:::::::::::::::::::> PUBLISH THE BANNERS <:::::::::::::::::::::::::::::::::::::

When you are finished customizing, you need to "Publish" the banner so that it can be used on the web. Go to File > Publish

For Google / Doubleclick banners, make sure all boxes are checked. 

:::::::::::::::::::> HOW TO PLACE YOUR BANNER ON A WEBPAGE <:::::::::::::::::::::::::::::::::::::

Upload your published banner files to a webserver.

The banners can be placed on a webpage with the "iframe" HTML markup. See sample code below:

<iframe src="300x600/300x600.html" frameborder="0" scrolling="no" width="300" height="600" style="background-color:#999;"></iframe>


:::::::::::::::::::> LINK DOWNLOAD IMAGE <:::::::::::::::::::::::::::::::::::::

http://photodune.net/item/my-move/3598692Need?ref=DemonSwith


:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


Please contact us if you have any questions or need assistance!

:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


More HTML5 banners can be found at: http://themeforest.net/user/demonswith



Enjoy!