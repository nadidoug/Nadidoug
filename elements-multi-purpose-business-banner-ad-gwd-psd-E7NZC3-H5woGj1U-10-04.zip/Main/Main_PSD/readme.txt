Author: iDoodle
File Name : Banner Ads - Multipurpose Banners Ads

Thank you for purchase!


DESCRIPTION :
------------------- 

Multipurpose Banners Ads Template is a clean and unique design so far using the latest trendy material design for introductions company, promotions, marketing, make money online…

BANNERS FEATURES :
------------------- 

- 06 template PSD files included

- 06 template HTML files included

- Google Ad Sizes

- Layered by name

- Fully editable – all colors and text can be modified.


FONTS USE :
------------------- 


+ Roboto ( http://www.dafont.com/roboto.font )

+ Century Gothic ( http://ufonts.com/download/century-gothic/24615.html )


NOTE
------------------- 

All the images are display only, not included in the main download package. They are not part of the theme and NOT included in the final purchase files.


Need another template or logo, please contact me directly via e-mail form on my profile page. 
